const form = document.getElementById("taskForm");
const taskList = document.getElementById("taskList");
const error = document.getElementById("error");

// Add delete functionality to existing tasks
const existingDeleteButtons = document.querySelectorAll(".delete-btn");

existingDeleteButtons.forEach(function(btn) {
btn.addEventListener("click", function() {
btn.parentElement.remove();
});
});

form.addEventListener("submit", function(e) {
e.preventDefault();


const title = document.getElementById("title").value;

// Validation
if (title === "") {
    error.textContent = "Task title is required";
    return;
}

error.textContent = "";

// Create new task
const li = document.createElement("li");
li.textContent = title + " ";

// Create delete button
const deleteBtn = document.createElement("button");
deleteBtn.textContent = "Delete";

// Delete functionality
deleteBtn.addEventListener("click", function() {
    li.remove();
});

// Add button inside li
li.appendChild(deleteBtn);

// Add to list
taskList.appendChild(li);

// Clear input
document.getElementById("title").value = "";


});
